#' @import pracma
#' @import dplyr
#' @import testthat
#' @import assertthat
#' @import rootSolve
